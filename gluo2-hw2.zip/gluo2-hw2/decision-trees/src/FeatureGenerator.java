package cs446.homework2;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;

public class FeatureGenerator {

    static String[] features;
    static String[] selfFeatures;
    private static FastVector zeroOne;
    private static FastVector labels;

    static {
	selfFeatures = new String[] { "firstName0", "firstName1", "firstName2", "firstName3", "firstName4",
				"lastName0", "lastName1", "lastName2", "lastName3","lastName4"};

	List<String> ff = new ArrayList<String>();

	for (String f : selfFeatures) {
	    for (char letter = 'a'; letter <= 'z'; letter++) {
		ff.add(f + "=" + letter);
	    }
	}

	features = ff.toArray(new String[ff.size()]);

	zeroOne = new FastVector(2);
	zeroOne.addElement("1");
	zeroOne.addElement("0");

	labels = new FastVector(2);
	labels.addElement("+");
	labels.addElement("-");
    }

    public static Instances readData(String[] fileNames) throws Exception {
	Instances instances = initializeAttributes();
	for(int i = 0; i < fileNames.length; i++){
	    Scanner scanner = new Scanner(new File(fileNames[i]));

	    while (scanner.hasNextLine()) {
		String line = scanner.nextLine();

		Instance instance = makeInstance(instances, line);

		instances.add(instance);
	    }

	    scanner.close();
	}

	return instances;
    }

    private static Instances initializeAttributes() {

	String nameOfDataset = "Badges";

	Instances instances;

	FastVector attributes = new FastVector(9);
	for (String featureName : features) {
	    attributes.addElement(new Attribute(featureName, zeroOne));
	}
	Attribute classLabel = new Attribute("Class", labels);
	attributes.addElement(classLabel);

	instances = new Instances(nameOfDataset, attributes, 0);

	instances.setClass(classLabel);

	return instances;

    }

    private static Instance makeInstance(Instances instances, String inputLine) {
	inputLine = inputLine.trim();

	String[] parts = inputLine.split("\\s+");
	String label = parts[0];
	String firstName = parts[1].toLowerCase();
	String lastName = parts[2].toLowerCase();

	Instance instance = new Instance(features.length + 1);
	instance.setDataset(instances);

	Set<String> feats = new HashSet<String>();

	for(int i = 0; i < 5; i++){
		if(i < firstName.length())
			feats.add(selfFeatures[i] + "=" + firstName.charAt(i));
	}
	for(int i = 0; i < 5; i++){
                if(i < lastName.length())
                        feats.add(selfFeatures[i+5] + "=" + lastName.charAt(i));
        }


	for (int featureId = 0; featureId < features.length; featureId++) {
	    Attribute att = instances.attribute(features[featureId]);

	    String name = att.name();
	    String featureLabel;
	    if (feats.contains(name)) {
		featureLabel = "1";
	    } else
		featureLabel = "0";
	    instance.setValue(att, featureLabel);
	}

	instance.setClassValue(label);

	return instance;
    }

    public static void main(String[] args) throws Exception {

	if (args.length < 2) {
	    System.err
		    .println("Usage: FeatureGenerator input-badges-file features-file");
	    System.exit(-1);
	}
	String[] dataToRead = new String[args.length-1];
	for(int i = 0; i < args.length-1; i++)
		dataToRead[i] = args[i];
	Instances data = readData(dataToRead);

	ArffSaver saver = new ArffSaver();
	saver.setInstances(data);
	saver.setFile(new File(args[args.length-1]));
	saver.writeBatch();
    }
}
