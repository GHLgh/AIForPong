package cs446.homework2;

import java.io.File;
import java.io.FileReader;

import weka.classifiers.Evaluation;
import weka.classifiers.Classifier;
import weka.classifiers.Sourcable;
import weka.core.Attribute;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.NoSupportForMissingValuesException;
import weka.core.RevisionUtils;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformationHandler;
import weka.core.Utils;
import weka.core.Capabilities.Capability;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;
import weka.core.FastVector;

import java.util.Enumeration;
import java.util.Random;

import cs446.weka.classifiers.trees.Id3;
import cs446.weka.classifiers.trees.SGD;

public class WekaTesterWithFiveFold {
    public static void main(String[] args) throws Exception {

	// NOTE: slightly different from the pseudo code from Piazza, parameters for SGD
	// 	 are passed with the weka tester is called
	if (args.length < 12) {
	    System.err.println("Usage: WekaTester train1-arff-file test1-arff-file train2-arff-file test2-arff-file train3-arff-file test3-arff-file train4-arff-file test4-arff-file train5-arff-file test5-arff-file Id3/learning-rate-double depth-int/threshold [stump-depth-SGD]");
	    System.exit(-1);
	}

	//Five Fold Section
	for(int i = 0; i < 5; i++){
	    // Load the data
	    // Training set
	    Instances trainingData = new Instances(new FileReader(new File(args[2*i])));
	    // Testing set
	    Instances testingData = new Instances(new FileReader(new File(args[2*i+1])));

	    // The last attribute is the class label
	    trainingData.setClassIndex(trainingData.numAttributes() - 1);
	    testingData.setClassIndex(testingData.numAttributes() - 1);

	    String id3 = "Id3";
	    if(id3.equals(args[10])){
		int depth = Integer.parseInt(args[11]);
		// Create a new ID3 classifier. This is the modified one where you can
   		// set the depth of the tree.
		Id3 classifier = new Id3();

		// An example depth. If this value is -1, then the tree is grown to full
		// depth.
	   	classifier.setMaxDepth(depth);

	    	// Train
	    	classifier.buildClassifier(trainingData);

	    	// Print the classfier
	    	System.out.println(classifier);
	    	System.out.println();

	    	// Evaluate on the test set
	    	Evaluation evaluation = new Evaluation(testingData);
	    	evaluation.evaluateModel(classifier, testingData);
	    	System.out.println(evaluation.toSummaryString());
	    }
	    else{
		// using stump as features for SGD
		if(args.length == 13){
		    int depth = Integer.parseInt(args[12]);
		    Id3[] treeClassifier = new Id3[100];

		    FastVector newAttributes = new FastVector(101);
		    FastVector boolVal = new FastVector(2);
		    boolVal.addElement("1");
 		    boolVal.addElement("0");

		    Attribute boolAttribute = new Attribute(String.valueOf(0),boolVal);
                    newAttributes.addElement(boolAttribute);

		    // train the trees
		    for(int j = 0; j < 100; j++){
			treeClassifier[j] = new Id3();
		 	treeClassifier[j].setMaxDepth(depth);

			trainingData.randomize(new Random());
			Instances train = trainingData.trainCV(2,j%2);
			treeClassifier[j].buildClassifier(train);

			boolAttribute = new Attribute(String.valueOf(j+1),boolVal);
			newAttributes.addElement(boolAttribute);
		    }

		    // Convert 260 features into 100 features from trained trees
		    Instances newTrainingSet = new Instances("train", newAttributes, trainingData.numInstances());
		    newTrainingSet.setClassIndex(100);
		    Enumeration instEnum = trainingData.enumerateInstances();
		    while (instEnum.hasMoreElements()) {
	        	Instance inst = (Instance) instEnum.nextElement();
			Instance newInstance = new Instance(101);
        	    	for(int j = 0; j < 100; j++){
			    newInstance.setValue((Attribute)newAttributes.elementAt(j),treeClassifier[j].classifyInstance(inst));
			}
			newInstance.setValue((Attribute)newAttributes.elementAt(100),inst.classValue());
			newTrainingSet.add(newInstance);
		    }
		    trainingData = newTrainingSet;

		    Instances newTestingSet = new Instances("test", newAttributes, testingData.numInstances());
                    newTestingSet.setClassIndex(100);
                    instEnum = testingData.enumerateInstances();
                    while (instEnum.hasMoreElements()) {
                        Instance inst = (Instance) instEnum.nextElement();
                        Instance newInstance = new Instance(101);
                        for(int j = 0; j < 100; j++){
                            newInstance.setValue((Attribute)newAttributes.elementAt(j),treeClassifier[j].classifyInstance(inst));
                        }
                        newInstance.setValue((Attribute)newAttributes.elementAt(100),inst.classValue());
			newTestingSet.add(newInstance);
                    }
		    testingData = newTestingSet;
		}
		double learningRate = Double.parseDouble(args[10]);
		double theshold = Double.parseDouble(args[11]);

		SGD classifier = new SGD();
		classifier.setParameter(learningRate, theshold);
		classifier.buildClassifier(trainingData);

                // Print the classfier
                System.out.println(classifier);
                System.out.println();

                // Evaluate on the test set
                Evaluation evaluation = new Evaluation(testingData);
                evaluation.evaluateModel(classifier, testingData);
                System.out.println(evaluation.toSummaryString());

	    }
	}
    }
}
