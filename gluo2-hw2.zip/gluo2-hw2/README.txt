Guanheng Luo, gluo2@illinois.edu

Tree files in this folder:
treeDisplay4.txt - Id3 decision tree with depth 4
treeDisplay8.txt - Id3 decision tree with depth 8
treeDisplayFull.txt - Id3 decision tree without depth limitation

To compile and run the code:
run test.sh in directory decision-tree, which will compile all the files, generate five fold data
and run (train and evaluate) classifier Id3 without limiation, Id3 with depth 4, Id3 with depth 8, SGD, SGD with decision trees as feature in order.
Note: the parameters for SGD used in test.sh is the parameters I used for writting the evaluation report.

Note that the program requires user input as parameters for classifier, please check the usage of WekaTesterWithFiveFold for detail.

Related files: (they are all in directory decision-tree/src)
WekaTesterWithFiveFold.java : entry for running classifiers, it can run Id3 with different depth, SGD and SGD with decision trees as feature based on arguments user enter.
Note: Decision stumps as features is implemented in this file. Besides that, you can perform any decision stumps as long as you enter valid arguments.

WekaTester : the original entry, it can only run Id3 with fix depth (14) and it does not support five fold.

SGD.java, Id3.java : file implemented corresponding algorithms.
Note that SGD.java is developed based on Id3.java, some functions that are not related to SGD are kept for the sake of avoiding possible error from removing functions needed for Weka.

FeatureGenerator.java : file that will generate 10 feature types and 26 boolean features with each type (first 5 letters in first and in last name), it is modified such that it can generate a continuous data set with multiple files in the similar format.
